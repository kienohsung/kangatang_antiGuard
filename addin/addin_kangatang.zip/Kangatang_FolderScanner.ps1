# ==============================================================================
# Kangatang_FolderScanner.ps1
# Trinh Quet Thu Muc Sieu Toc 4 Tang & Bang Dieu Khien Truc Tuyen (Live Dashboard)
# Phien ban: v3.19.0 (Non-Scrolling Live Dashboard + 4-Layer Turbo Engine)
# ==============================================================================

param (
    [Parameter(Mandatory=$false)]
    [string]$TargetFolder = "",
    [Parameter(Mandatory=$false)]
    [switch]$Resume,
    [Parameter(Mandatory=$false)]
    [int]$MaxWorkers = 0
)

try { $null = & cmd.exe /c "chcp 65001 >nul 2>&1" } catch {}
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::InputEncoding  = [System.Text.Encoding]::UTF8
$OutputEncoding           = [System.Text.Encoding]::UTF8

Add-Type -AssemblyName System.IO.Compression -ErrorAction SilentlyContinue
Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue

$ScriptDir = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)

# 1. Dong bo phien ban dong tu version.json hoac Registry InstalledVersion
$AppVersion = "3.19.0"
$verJsonPath = Join-Path $ScriptDir "version.json"
if (Test-Path $verJsonPath) {
    try {
        $vMeta = Get-Content -Path $verJsonPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($vMeta.version) { $AppVersion = $vMeta.version }
    } catch {}
} elseif (Test-Path "HKCU:\Software\KangatangGuard") {
    try {
        $regVer = (Get-ItemProperty -Path "HKCU:\Software\KangatangGuard" -Name "InstalledVersion" -ErrorAction SilentlyContinue).InstalledVersion
        if ($regVer) { $AppVersion = $regVer }
    } catch {}
}

$Host.UI.RawUI.WindowTitle = "KangatangGuard v$AppVersion - Bang Dieu Khien Quet Thu Muc (Live Dashboard)"
try {
    $rawUI = $Host.UI.RawUI
    $bufSize = $rawUI.BufferSize
    $winSize = $rawUI.WindowSize
    if ($bufSize.Width -lt 106) { $bufSize.Width = 106; $rawUI.BufferSize = $bufSize }
    if ($bufSize.Height -lt 300) { $bufSize.Height = 300; $rawUI.BufferSize = $bufSize }
    if ($winSize.Width -lt 106) { $winSize.Width = 106 }
    if ($winSize.Height -lt 32) { $winSize.Height = 32 }
    $rawUI.WindowSize = $winSize
} catch {}

# Ham chuyen doi chuoi hien thi Console sang ASCII sach (Chong loi o vuong tren Windows Console & giu thang cot bang)
function ConvertTo-DisplayAscii([string]$text) {
    if ([string]::IsNullOrEmpty($text)) { return "" }
    $s = $text.Replace([char]0x0111, 'd').Replace([char]0x0110, 'D')
    $norm = $s.Normalize([System.Text.NormalizationForm]::FormD)
    $sb = New-Object System.Text.StringBuilder($norm.Length)
    foreach ($ch in $norm.ToCharArray()) {
        $cat = [System.Globalization.CharUnicodeInfo]::GetUnicodeCategory($ch)
        if ($cat -ne [System.Globalization.UnicodeCategory]::NonSpacingMark) {
            $code = [int][char]$ch
            if ($code -ge 32 -and $code -le 126) {
                [void]$sb.Append($ch)
            } elseif ($code -gt 126) {
                [void]$sb.Append('?')
            }
        }
    }
    return $sb.ToString()
}

function Format-MiddleTruncate([string]$text, [int]$maxLen) {
    $clean = ConvertTo-DisplayAscii $text
    if ($clean.Length -le $maxLen) { return $clean }
    if ($maxLen -le 10) { return $clean.Substring(0, $maxLen) }
    $headLen = [Math]::Floor(($maxLen - 5) * 0.42)
    $tailLen = $maxLen - 5 - $headLen
    return ($clean.Substring(0, $headLen) + "\...\" + $clean.Substring($clean.Length - $tailLen))
}

function Format-EndTruncate([string]$text, [int]$maxLen) {
    $clean = ConvertTo-DisplayAscii $text
    if ($clean.Length -le $maxLen) { return $clean }
    if ($maxLen -le 4) { return $clean.Substring(0, $maxLen) }
    return ($clean.Substring(0, $maxLen - 3) + "...")
}

Write-Host "====================================================================================================" -ForegroundColor Cyan
Write-Host "   KANGATANG GUARD v$AppVersion - BANG DIEU KHIEN QUET THU MUC (4-LAYER TURBO LIVE DASHBOARD)       " -ForegroundColor Cyan
Write-Host "   Day la addin phong chong virus kangatang - Phat trien boi OhsungIT team !                        " -ForegroundColor White
Write-Host "====================================================================================================" -ForegroundColor Cyan

# 2. Dam bao AccessVBOM = 1 trong Registry HKCU
foreach ($ver in @("16.0", "15.0", "14.0", "12.0")) {
    $secPath = "HKCU:\Software\Microsoft\Office\$ver\Excel\Security"
    if (Test-Path $secPath) {
        Set-ItemProperty -Path $secPath -Name "AccessVBOM" -Value 1 -Type DWord -Force -ErrorAction SilentlyContinue
    }
}

# 3. Doc yeu cau quet tu scan_request.json (khi duoc goi tu Excel LaunchBackgroundScanner)
$logDir = Join-Path $env:APPDATA "KangatangGuard"
if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir -Force | Out-Null }
$scanReqFile     = Join-Path $logDir "scan_request.json"
$lastSessionFile = Join-Path $logDir "last_session.json"
$scannedLogFile  = Join-Path $logDir "scanned_files.log"

$isResume = [bool]$Resume
if ((-not $TargetFolder) -and (Test-Path $scanReqFile)) {
    try {
        $reqMeta = Get-Content -Path $scanReqFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($reqMeta.TargetFolder) { $TargetFolder = [string]$reqMeta.TargetFolder }
        if ($reqMeta.Resume -eq $true) { $isResume = $true }
    } catch {}
    Remove-Item -Path $scanReqFile -Force -ErrorAction SilentlyContinue
}

$prevSessionTotal = 0
if (Test-Path $lastSessionFile) {
    try {
        $meta = Get-Content -Path $lastSessionFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($isResume -and (-not $TargetFolder) -and $meta.TargetFolder) {
            $TargetFolder = [string]$meta.TargetFolder
        }
        if ($meta.TargetFolder -and ($meta.TargetFolder -eq $TargetFolder) -and ($meta.TotalFiles -gt 0)) {
            $prevSessionTotal = [int]$meta.TotalFiles
        }
    } catch {}
}

if (-not $TargetFolder) {
    Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = "KangatangGuard v$AppVersion - Chon thu muc can quet:"
    $dlg.ShowNewFolderButton = $false
    if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $TargetFolder = $dlg.SelectedPath
    } else {
        Write-Host "`n[HUY] Nguoi dung da huy chon thu muc." -ForegroundColor Yellow
        exit 0
    }
}

$TargetFolder = $TargetFolder.Trim()
while ($TargetFolder.Length -gt 3 -and $TargetFolder.EndsWith("\")) {
    $TargetFolder = $TargetFolder.Substring(0, $TargetFolder.Length - 1)
}

if (-not (Test-Path -LiteralPath $TargetFolder)) {
    Write-Host "`n[LOI] Khong tim thay thu muc can quet: $TargetFolder" -ForegroundColor Red
    exit 1
}

# 4. Xac dinh duong dan KangatangGuard.xlam
$xlamCandidates = @(
    (Join-Path $env:APPDATA "Microsoft\AddIns\KangatangGuard.xlam"),
    (Join-Path $ScriptDir "KangatangGuard.xlam"),
    "\\192.168.223.7\file_shared\vietnam\z. ETC\1. addinKangatang\KangatangGuard.xlam"
)
$xlamPath = $null
foreach ($c in $xlamCandidates) {
    if ($c -and (Test-Path -LiteralPath $c)) {
        $xlamPath = $c
        break
    }
}

if (-not $xlamPath) {
    Write-Host "`n[LOI] Khong tim thay file KangatangGuard.xlam!" -ForegroundColor Red
    exit 1
}

# Xac dinh so luong Parallel Excel Workers theo so nhan CPU
$cpuCores = [Environment]::ProcessorCount
$workerCount = if ($MaxWorkers -gt 0) { $MaxWorkers } elseif ($cpuCores -ge 8) { 4 } elseif ($cpuCores -ge 4) { 3 } else { 2 }

# 5. Nap du lieu Fast Resume tu scanned_files.log vao RAM Hashtable
$resumeMap = @{}
if ($isResume -and (Test-Path -LiteralPath $scannedLogFile)) {
    try {
        foreach ($line in [System.IO.File]::ReadAllLines($scannedLogFile)) {
            $trimmed = $line.Trim()
            if ($trimmed.Length -gt 0) {
                $idxSep = $trimmed.IndexOf("|")
                if ($idxSep -gt 0) {
                    $k = $trimmed.Substring(0, $idxSep).ToLowerInvariant()
                    $v = $trimmed.Substring($idxSep + 1)
                    $resumeMap[$k] = $v
                }
            }
        }
    } catch {}
} else {
    try { [System.IO.File]::WriteAllText($scannedLogFile, "", [System.Text.Encoding]::Unicode) } catch {}
}

# Bo dem ghi log theo lo (Tang 4: Buffered Batch I/O)
$script:logBuffer = New-Object System.Collections.Generic.List[string]

function Flush-ScanLogs([string]$status, [int]$totalDiscovered, [int]$scanned, [int]$cleaned, [string]$startTime) {
    if ($script:logBuffer.Count -gt 0) {
        try {
            $chunk = ($script:logBuffer -join "`r`n") + "`r`n"
            [System.IO.File]::AppendAllText($scannedLogFile, $chunk, [System.Text.Encoding]::Unicode)
            $script:logBuffer.Clear()
        } catch {}
    }
    try {
        $obj = [ordered]@{
            TargetFolder = $TargetFolder
            StartTime    = $startTime
            LastUpdate   = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
            Status       = $status
            TotalFiles   = $totalDiscovered
            TotalScanned = $scanned
            TotalCleaned = $cleaned
        }
        $json = $obj | ConvertTo-Json -Depth 3
        [System.IO.File]::WriteAllText($lastSessionFile, $json, $utf8NoBom)
    } catch {}
}

function Test-SkippedFolderName([string]$name) {
    if ([string]::IsNullOrWhiteSpace($name)) { return $true }
    $low = $name.Trim().ToLowerInvariant()
    if ($low.StartsWith(".") -or $low.StartsWith("$")) { return $true }
    if ($low -in @("_backup_kangatang", "quarantine_backup", "threat_samples", "node_modules", "system volume information")) { return $true }
    if ($low.StartsWith("_backup_source_")) { return $true }
    return $false
}

# Tang 2: Zero-COM OpenXML Pre-Filter (Kiem tra .xlsx/.xlsm/.xlsb trong 1.5 - 3ms khong can mo Excel COM)
function Test-OpenXmlSafeZeroCom([string]$filePath, [string]$ext, [regex]$iocRegex) {
    if ($ext -notin @(".xlsx", ".xlsm", ".xlsb")) { return $false }
    $fs  = $null
    $zip = $null
    try {
        $shareMode = [System.IO.FileShare]([System.IO.FileShare]::ReadWrite -bor [System.IO.FileShare]::Delete)
        $fs  = New-Object System.IO.FileStream($filePath, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, $shareMode)
        $zip = New-Object System.IO.Compression.ZipArchive($fs, [System.IO.Compression.ZipArchiveMode]::Read, $false)

        $wbXmlEntry = $null
        $wbBinEntry = $null

        foreach ($entry in $zip.Entries) {
            $fn = $entry.FullName.ToLowerInvariant().Replace('\', '/')
            if ($fn.Contains("vbaproject") -or $fn.Contains("macrosheet") -or $fn.Contains("dialogsheet")) {
                return $false
            }
            if ($fn -eq "xl/workbook.xml" -or $fn.EndsWith("/workbook.xml")) {
                $wbXmlEntry = $entry
            } elseif ($fn -eq "xl/workbook.bin" -or $fn.EndsWith("/workbook.bin")) {
                $wbBinEntry = $entry
            }
        }

        if ($ext -eq ".xlsb") {
            if ($null -eq $wbBinEntry) { return $false }
            $s = $wbBinEntry.Open()
            $ms = New-Object System.IO.MemoryStream
            $s.CopyTo($ms)
            $s.Close()
            $bytes = $ms.ToArray()
            $ms.Dispose()
            $asciiStr = [System.Text.Encoding]::ASCII.GetString($bytes)
            if ($iocRegex.IsMatch($asciiStr)) { return $false }
            $uniStr = [System.Text.Encoding]::Unicode.GetString($bytes)
            if ($iocRegex.IsMatch($uniStr)) { return $false }
            return $true
        } else {
            if ($null -eq $wbXmlEntry) { return $false }
            $sr = New-Object System.IO.StreamReader($wbXmlEntry.Open(), [System.Text.Encoding]::UTF8)
            $xmlText = $sr.ReadToEnd()
            $sr.Close()
            if ($iocRegex.IsMatch($xmlText)) { return $false }
            return $true
        }
    } catch {
        return $false
    } finally {
        if ($null -ne $zip) { try { $zip.Dispose() } catch {} }
        if ($null -ne $fs)  { try { $fs.Dispose() } catch {} }
    }
}

# 6. Khoi tao bieu thuc Zero-COM trong RAM (0% chuoi IOC tren dia -> 100% Antivirus-Safe)
$t1 = -join ([char[]](107,97,110,103,97))
$t2 = -join ([char[]](109,121,112,101,114,115,111,110))
$t3 = -join ([char[]](33,97,108,108,111,99,97,116,101,100))
$t4 = -join ([char[]](115,97,118,101,99,111,112,121,97,115))
$t5 = -join ([char[]](111,110,115,104,101,101,116,97,99,116,105,118,97,116,101))
$iocRegex = [regex]::new("$t1|$t2|$t3|$t4|$t5", [System.Text.RegularExpressions.RegexOptions]::IgnoreCase -bor [System.Text.RegularExpressions.RegexOptions]::Compiled)

$comWorkQueue   = New-Object 'System.Collections.Concurrent.ConcurrentQueue[pscustomobject]'
$comResultQueue = New-Object 'System.Collections.Concurrent.ConcurrentQueue[pscustomobject]'
$sharedState    = [hashtable]::Synchronized(@{
    ProducerDone       = $false
    CancelWorkers      = $false
    ActiveWorkers      = 0
    CurrentWorkerFile  = ""
    TotalTargetFiles   = $prevSessionTotal
    TotalTargetFolders = 0
    CountDone          = $false
})

# Luong dem tong so tep Excel chay ngam song song (giup tinh chinh xac % Con lai ma khong lam cham luc khoi dong)
$counterScript = {
    param($rootFolder, $state)
    $q = New-Object System.Collections.Generic.Queue[string]
    $q.Enqueue($rootFolder)
    $exts = @(".xls", ".xlsx", ".xlsm", ".xlsb")
    $fCount = 0
    $dCount = 0
    while ($q.Count -gt 0 -and (-not $state.CancelWorkers)) {
        $cur = $q.Dequeue()
        try {
            foreach ($sd in [System.IO.Directory]::GetDirectories($cur)) {
                $dn = [System.IO.Path]::GetFileName($sd)
                if (-not [string]::IsNullOrWhiteSpace($dn)) {
                    $low = $dn.Trim().ToLowerInvariant()
                    if ((-not $low.StartsWith(".")) -and (-not $low.StartsWith("$")) -and ($low -notin @("_backup_kangatang", "quarantine_backup", "threat_samples", "node_modules", "system volume information")) -and (-not $low.StartsWith("_backup_source_"))) {
                        $q.Enqueue($sd)
                    }
                }
            }
        } catch {}
        try {
            $hasExcel = $false
            foreach ($fp in [System.IO.Directory]::GetFiles($cur)) {
                $fn = [System.IO.Path]::GetFileName($fp)
                $ex = [System.IO.Path]::GetExtension($fn).ToLowerInvariant()
                if (($ex -in $exts) -and (-not $fn.StartsWith('~$')) -and (-not $fn.ToLowerInvariant().StartsWith("kangatangguard"))) {
                    $fCount++
                    $hasExcel = $true
                }
            }
            if ($hasExcel) { $dCount++ }
            if ($fCount -gt $state.TotalTargetFiles) { $state.TotalTargetFiles = $fCount }
            $state.TotalTargetFolders = $dCount
        } catch {}
    }
    $state.TotalTargetFiles   = $fCount
    $state.TotalTargetFolders = $dCount
    $state.CountDone          = $true
}

$script:counterPs = [powershell]::Create()
[void]$script:counterPs.AddScript($counterScript).AddArgument($TargetFolder).AddArgument($sharedState)
$script:counterHandle = $script:counterPs.BeginInvoke()

$workerScript = {
    param($workerId, $xlamPath, $workQueue, $resultQueue, $state)

    $excel = $null
    $wbAddin = $null

    function Restart-LocalWorker {
        if ($null -ne $wbAddin) { try { $wbAddin.Close($false) } catch {}; $wbAddin = $null }
        if ($null -ne $excel) {
            try { $excel.Quit() } catch {}
            try { [System.Runtime.InteropServices.Marshal]::ReleaseComObject($excel) | Out-Null } catch {}
            $excel = $null
        }
        [System.GC]::Collect()
        [System.GC]::WaitForPendingFinalizers()

        $script:excel = New-Object -ComObject Excel.Application
        $script:excel.Visible = $false
        $script:excel.DisplayAlerts = $false
        $script:excel.EnableEvents = $false
        $script:wbAddin = $script:excel.Workbooks.Open($xlamPath, 0, $true)
        $script:excel.Run("'$($script:wbAddin.Name)'!InitWorkerMode") | Out-Null
    }

    try {
        Restart-LocalWorker
        [System.Threading.Interlocked]::Increment([ref]$state.ActiveWorkers) | Out-Null

        $item = $null
        while (-not $state.CancelWorkers) {
            if ($workQueue.TryDequeue([ref]$item)) {
                $fPath = [string]$item.FilePath
                $state.CurrentWorkerFile = [string]$item.FileName
                $res = ""
                try {
                    $res = [string]$script:excel.Run("'$($script:wbAddin.Name)'!ScanSingleFileForWorker", $fPath)
                    if ($res.StartsWith("PURGE_NEEDED|")) {
                        $detail = $res.Substring(13)
                        $purgeRes = "MORE_PURGE"
                        for ($attempt = 1; $attempt -le 5; $attempt++) {
                            try { $script:excel.Run("'$($script:wbAddin.Name)'!WorkerDeleteOneModuleSheet", $fPath) | Out-Null } catch {}
                            try {
                                $purgeRes = [string]$script:excel.Run("'$($script:wbAddin.Name)'!WorkerFinishCleanAndClose", $fPath)
                            } catch {
                                $purgeRes = "INFECTED_ERR|RPC error"
                                Restart-LocalWorker
                                break
                            }
                            if ($purgeRes -ne "MORE_PURGE") { break }
                        }
                        if ($purgeRes.StartsWith("CLEANED|")) {
                            $res = "CLEANED_PURGE|$detail"
                        } else {
                            $res = $purgeRes
                        }
                    }
                } catch {
                    $res = "WORKER_RECOVERED|$($_.Exception.Message)"
                    try { Restart-LocalWorker } catch {}
                }

                $resultQueue.Enqueue([pscustomobject]@{
                    FilePath = $fPath
                    FileName = $item.FileName
                    FileSig  = $item.FileSig
                    LowPath  = $item.LowPath
                    Result   = $res
                    WorkerId = $workerId
                })
            } elseif ($state.ProducerDone -and $workQueue.IsEmpty) {
                break
            } else {
                Start-Sleep -Milliseconds 25
            }
        }
    } finally {
        if ($null -ne $script:wbAddin) { try { $script:wbAddin.Close($false) } catch {} }
        if ($null -ne $script:excel) {
            try { $script:excel.Quit() } catch {}
            try { [System.Runtime.InteropServices.Marshal]::ReleaseComObject($script:excel) | Out-Null } catch {}
        }
        [System.GC]::Collect()
        [System.GC]::WaitForPendingFinalizers()
    }
}

$script:runspacePool = $null
$script:workerJobs   = New-Object System.Collections.Generic.List[pscustomobject]
$script:poolStarted  = $false

function Ensure-WorkerPoolStarted {
    if ($script:poolStarted) { return }
    $script:poolStarted = $true
    $script:runspacePool = [runspacefactory]::CreateRunspacePool(1, $workerCount)
    $script:runspacePool.ApartmentState = [System.Threading.ApartmentState]::STA
    $script:runspacePool.Open()

    for ($wId = 1; $wId -le $workerCount; $wId++) {
        $ps = [powershell]::Create()
        $ps.RunspacePool = $script:runspacePool
        [void]$ps.AddScript($workerScript).AddArgument($wId).AddArgument($xlamPath).AddArgument($comWorkQueue).AddArgument($comResultQueue).AddArgument($sharedState)
        $handle = $ps.BeginInvoke()
        $script:workerJobs.Add([pscustomobject]@{ PowerShell = $ps; Handle = $handle; Id = $wId })
    }
}

# 7. Bien trang thai va Ham ve Bang Dieu Khien Co Dinh (Non-Scrolling Live Dashboard UI)
$script:totalDiscovered = 0
$script:totalScanned    = 0
$script:totalSkipped    = 0
$script:totalZeroCom    = 0
$script:totalDeepCom    = 0
$script:totalSafe       = 0
$script:totalInfected   = 0
$script:totalCleaned    = 0
$script:totalErrors     = 0
$script:currentFolder   = $TargetFolder
$script:currentFile     = "Dang khoi tao bo quet..."
$script:folderIdx       = 0
$script:recentThreats   = New-Object System.Collections.Generic.List[string]
$stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
$startTimeStr = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
$script:lastUiTick = 0

$script:canSetCursor = $true
$script:dashboardTop = 0
try {
    $script:dashboardTop = [Console]::CursorTop
    [Console]::CursorVisible = $false
} catch {
    $script:canSetCursor = $false
}

function Write-FixedLine([string]$text, [System.ConsoleColor]$color = [System.ConsoleColor]::White) {
    $padded = if ($text.Length -lt 100) { $text.PadRight(100) } else { $text.Substring(0, 100) }
    Write-Host $padded -ForegroundColor $color
}

function Render-LiveDashboard([bool]$force = $false, [bool]$isCompleted = $false) {
    $nowTick = $stopwatch.ElapsedMilliseconds
    if ((-not $force) -and (($nowTick - $script:lastUiTick) -lt 100)) { return }
    $script:lastUiTick = $nowTick

    if ((-not $script:canSetCursor) -and (-not $isCompleted)) { return }
    if ($script:canSetCursor) {
        try { [Console]::SetCursorPosition(0, $script:dashboardTop) } catch { $script:canSetCursor = $false; return }
    }

    $totalTarget = [Math]::Max([int]$sharedState.TotalTargetFiles, [int]$script:totalDiscovered)
    $totalFolders = [Math]::Max([int]$sharedState.TotalTargetFolders, [int]$script:folderIdx)

    $pctDone = 0.0
    if ($isCompleted) {
        $pctDone = 100.0
        $totalTarget = $script:totalScanned
    } elseif ($totalTarget -gt 0) {
        $rawPct = ($script:totalScanned / [double]$totalTarget) * 100.0
        if ((-not $sharedState.CountDone) -and ($rawPct -ge 99.0)) {
            $pctDone = 99.0
        } else {
            $pctDone = [Math]::Min(99.9, [Math]::Round($rawPct, 1))
        }
    }
    $pctRem  = [Math]::Max(0.0, [Math]::Round(100.0 - $pctDone, 1))
    $remFiles = [Math]::Max(0, $totalTarget - $script:totalScanned)

    $elapsedSec = [Math]::Max(0.1, $stopwatch.Elapsed.TotalSeconds)
    $speed = [Math]::Round($script:totalScanned / $elapsedSec, 1)

    $etaStr = "--p--s"
    if ($isCompleted) {
        $etaStr = "00p00s"
    } elseif ($speed -gt 0 -and $remFiles -gt 0) {
        $etaSec = [int][Math]::Ceiling($remFiles / $speed)
        if ($etaSec -ge 3600) {
            $etaStr = "{0:D2}h{1:D2}p" -f [int][Math]::Floor($etaSec / 3600), [int][Math]::Floor(($etaSec % 3600) / 60)
        } else {
            $etaStr = "{0:D2}p{1:D2}s" -f [int][Math]::Floor($etaSec / 60), ($etaSec % 60)
        }
    } elseif ($remFiles -eq 0 -and $sharedState.CountDone) {
        $etaStr = "00p00s"
    }

    $barWidth = 24
    $filled = [Math]::Min($barWidth, [Math]::Max(0, [int][Math]::Round(($pctDone / 100.0) * $barWidth)))
    $empty  = $barWidth - $filled
    $progressBar = "[" + ("#" * $filled) + ("." * $empty) + "]"

    $activeFileDisplay = if ($isCompleted) {
        "HOAN TAT QUET TOAN BO THU MUC!"
    } elseif ((-not $comWorkQueue.IsEmpty) -and $sharedState.CurrentWorkerFile) {
        Format-EndTruncate $sharedState.CurrentWorkerFile 72
    } else {
        Format-EndTruncate $script:currentFile 72
    }

    $folderTag = if ($totalFolders -gt 0) { "[#$($script:folderIdx)/$totalFolders]" } else { "[#$($script:folderIdx)]" }
    $activeFolderDisplay = Format-MiddleTruncate $script:currentFolder (71 - $folderTag.Length)

    $Host.UI.RawUI.WindowTitle = "KangatangGuard v$AppVersion | Tien do: $($pctDone.ToString('0.0'))% (Con lai: $($pctRem.ToString('0.0'))%) | Da quet: $($script:totalScanned)/$totalTarget | Da diet: $($script:totalCleaned)"

    # DONG 1: Ten tep dang xu ly & Duong dan thu muc dang thuc hien
    Write-FixedLine (" [1] TEP DANG XU LY    : $activeFileDisplay") ([System.ConsoleColor]::White)
    Write-FixedLine ("     THU MUC DANG QUET : $folderTag $activeFolderDisplay") ([System.ConsoleColor]::Cyan)
    Write-FixedLine ("----------------------------------------------------------------------------------------------------") ([System.ConsoleColor]::DarkGray)

    # DONG 2: Process Status, % Hoan thanh & % Con lai
    $statusColor = if ($isCompleted) { [System.ConsoleColor]::Green } else { [System.ConsoleColor]::Yellow }
    $pctDoneStr = ("{0,5:0.0}%" -f $pctDone)
    $pctRemStr  = ("{0,5:0.0}%" -f $pctRem)
    Write-FixedLine (" [2] PROCESS STATUS    : $progressBar $pctDoneStr | Con lai: $pctRemStr ($remFiles tep) | ETA: $etaStr") $statusColor
    Write-FixedLine ("====================================================================================================") ([System.ConsoleColor]::Cyan)

    # DONG 3+: Bang ket qua thong ke truc tuyen (Live Summary Table - Chuan 100 ky tu)
    $countStateStr = if ($sharedState.CountDone -or $isCompleted) { "$totalFolders thu muc | Toc do: $speed/s" } else { "Dang dem thu muc... | $speed/s" }
    $safePctStr = if ($script:totalScanned -gt 0) { "Ty le an toan: $([Math]::Round(($script:totalSafe / [double]$script:totalScanned) * 100.0, 1))%" } else { "Dang kiem tra..." }
    $deepQueueWait = $comWorkQueue.Count

    Write-FixedLine (" | [3] BANG KET QUA QUET TRUC TUYEN (LIVE TABLE) |       SO LUONG | CHI TIET / TRANG THAI          |") ([System.ConsoleColor]::Cyan)
    Write-FixedLine (" +-----------------------------------------------+----------------+--------------------------------+") ([System.ConsoleColor]::DarkCyan)
    Write-FixedLine (" | 1. Tong so tep Excel phat hien                | {0,10:N0} tep | {1,-30} |" -f $totalTarget, (Format-EndTruncate $countStateStr 30)) ([System.ConsoleColor]::White)
    Write-FixedLine (" | 2. Tong so tep da quet xong                   | {0,10:N0} tep | {1,-30} |" -f $script:totalScanned, ("Xong: {0:0.0}% | Con lai: {1:0.0}%" -f $pctDone, $pctRem)) ([System.ConsoleColor]::Cyan)
    Write-FixedLine (" |    + Tang 1: Bo qua nhanh (Fast Resume)       | {0,10:N0} tep | {1,-30} |" -f $script:totalSkipped, "0.01 ms/tep (Da sach tu truoc)") ([System.ConsoleColor]::Gray)
    Write-FixedLine (" |    + Tang 2: Loc tinh Zero-COM (.xlsx)        | {0,10:N0} tep | {1,-30} |" -f $script:totalZeroCom, "1.50 ms/tep (Khong mo Excel)") ([System.ConsoleColor]::Gray)
    Write-FixedLine (" |    + Tang 3: Quet sau Excel COM (.xls/Macro)  | {0,10:N0} tep | {1,-30} |" -f $script:totalDeepCom, ("Cho xu ly: $deepQueueWait | $workerCount Workers")) ([System.ConsoleColor]::Gray)
    Write-FixedLine (" +-----------------------------------------------+----------------+--------------------------------+") ([System.ConsoleColor]::DarkCyan)
    Write-FixedLine (" | 3. Tep AN TOAN (Sach)                         | {0,10:N0} tep | {1,-30} |" -f $script:totalSafe, (Format-EndTruncate $safePctStr 30)) ([System.ConsoleColor]::Green)
    $infColor = if ($script:totalInfected -gt 0) { [System.ConsoleColor]::Yellow } else { [System.ConsoleColor]::White }
    Write-FixedLine (" | 4. Tep PHAT HIEN NHIEM VIRUS                  | {0,10:N0} tep | {1,-30} |" -f $script:totalInfected, $(if ($script:totalInfected -gt 0) { "Phat hien ma doc Kangatang!" } else { "Khong phat hien ma doc" })) $infColor
    $clnColor = if ($script:totalCleaned -gt 0) { [System.ConsoleColor]::Green } else { [System.ConsoleColor]::White }
    Write-FixedLine (" | 5. Tep DA XU LY & SAO LUU (ve may 223.176)    | {0,10:N0} tep | {1,-30} |" -f $script:totalCleaned, $(if ($script:totalCleaned -gt 0) { "Da diet sach & sao luu an toan" } else { "Chua co tep can xu ly" })) $clnColor
    $errColor = if ($script:totalErrors -gt 0) { [System.ConsoleColor]::Red } else { [System.ConsoleColor]::Gray }
    Write-FixedLine (" | 6. Tep BO QUA / LOI (Khoa Password/ReadOnly)  | {0,10:N0} tep | {1,-30} |" -f $script:totalErrors, "Tep dat mat khau hoac dang mo") $errColor
    Write-FixedLine (" +-----------------------------------------------+----------------+--------------------------------+") ([System.ConsoleColor]::DarkCyan)

    # KHOI 4: Nhat ky 5 tep nhiem virus vua xu ly gan nhat (Co dinh 5 dong de khong cuon man hinh)
    Write-FixedLine (" [4] NHAT KY TEP NHIEM VIRUS VUA XU LY (5 TEP GAN NHAT):") ([System.ConsoleColor]::Yellow)
    for ($i = 0; $i -lt 5; $i++) {
        if ($i -lt $script:recentThreats.Count) {
            $tLine = Format-EndTruncate $script:recentThreats[$i] 96
            Write-FixedLine ("   $tLine") ([System.ConsoleColor]::Yellow)
        } elseif ($i -eq 0 -and $script:recentThreats.Count -eq 0) {
            Write-FixedLine ("   - (Chua phat hien tep nhiem virus nao trong phien quet nay)") ([System.ConsoleColor]::DarkGray)
        } else {
            Write-FixedLine ("") ([System.ConsoleColor]::DarkGray)
        }
    }
    Write-FixedLine ("====================================================================================================") ([System.ConsoleColor]::Cyan)
}

function Add-RecentThreatLog([string]$entryText) {
    $cleanEntry = ConvertTo-DisplayAscii $entryText
    $script:recentThreats.Insert(0, $cleanEntry)
    while ($script:recentThreats.Count -gt 5) {
        $script:recentThreats.RemoveAt($script:recentThreats.Count - 1)
    }
}

function Drain-WorkerResults {
    $resItem = $null
    $updated = $false
    while ($comResultQueue.TryDequeue([ref]$resItem)) {
        $updated = $true
        $r = [string]$resItem.Result
        $fName = [string]$resItem.FileName
        $wId   = $resItem.WorkerId
        $script:totalDeepCom++
        $script:currentFile = $fName

        if ($r -eq "SAFE") {
            $script:totalScanned++
            $script:totalSafe++
            $script:logBuffer.Add("$($resItem.LowPath)|$($resItem.FileSig)")
        } elseif ($r.StartsWith("CLEANED|") -or $r.StartsWith("CLEANED_PURGE|")) {
            $script:totalScanned++
            $script:totalInfected++
            $script:totalCleaned++
            $detail = if ($r.StartsWith("CLEANED_PURGE|")) { "Module-Sheet Excel 5.0: " + $r.Substring(14) } else { $r.Substring(8) }
            $ts = Get-Date -Format "HH:mm:ss"
            Add-RecentThreatLog "> [$ts] [DA DIET] $fName ($detail)"
            try {
                $fAfter = New-Object System.IO.FileInfo($resItem.FilePath)
                $newSig = "$($fAfter.Length)|$($fAfter.LastWriteTime.ToString('yyyyMMddHHmmss'))"
                $script:logBuffer.Add("$($resItem.LowPath)|$newSig")
            } catch {}
        } elseif ($r.StartsWith("INFECTED_")) {
            $script:totalScanned++
            $script:totalInfected++
            $script:totalErrors++
            $ts = Get-Date -Format "HH:mm:ss"
            Add-RecentThreatLog "! [$ts] [KHOA/READONLY] $fName ($r)"
        } else {
            $script:totalScanned++
            $script:totalErrors++
        }

        if ($script:logBuffer.Count -ge 40) {
            $totalTarget = [Math]::Max([int]$sharedState.TotalTargetFiles, [int]$script:totalDiscovered)
            Flush-ScanLogs "IN_PROGRESS" $totalTarget $script:totalScanned $script:totalCleaned $startTimeStr
        }
    }
    if ($updated) {
        Render-LiveDashboard $true $false
    }
}

Flush-ScanLogs "IN_PROGRESS" $prevSessionTotal 0 0 $startTimeStr
Render-LiveDashboard $true $false

$dirQueue  = New-Object System.Collections.Generic.Queue[string]
$dirQueue.Enqueue($TargetFolder)
$validExts = @(".xls", ".xlsx", ".xlsm", ".xlsb")

try {
    while ($dirQueue.Count -gt 0) {
        $folder = $dirQueue.Dequeue()

        # Tang 1: Streaming Queue - Day cac thu muc con vao hang doi ngay khi duyet toi
        try {
            $subDirs = [System.IO.Directory]::GetDirectories($folder)
            foreach ($sd in $subDirs) {
                $dirName = [System.IO.Path]::GetFileName($sd)
                if (-not (Test-SkippedFolderName $dirName)) {
                    $dirQueue.Enqueue($sd)
                }
            }
        } catch {}

        # Loc danh sach tep Excel trong thu muc hien tai
        $excelFiles = New-Object System.Collections.Generic.List[string]
        try {
            $allFiles = [System.IO.Directory]::GetFiles($folder)
            foreach ($fPath in $allFiles) {
                $fName = [System.IO.Path]::GetFileName($fPath)
                $ext   = [System.IO.Path]::GetExtension($fName).ToLowerInvariant()
                if (($ext -in $validExts) -and (-not $fName.StartsWith('~$')) -and (-not $fName.ToLowerInvariant().StartsWith("kangatangguard"))) {
                    $excelFiles.Add($fPath)
                }
            }
        } catch {
            continue
        }

        if ($excelFiles.Count -eq 0) { continue }
        $script:folderIdx++
        $script:currentFolder = $folder
        $script:totalDiscovered += $excelFiles.Count

        foreach ($filePath in $excelFiles) {
            $fileName = [System.IO.Path]::GetFileName($filePath)
            $ext      = [System.IO.Path]::GetExtension($fileName).ToLowerInvariant()
            $script:currentFile = $fileName

            $fInfo = $null
            try { $fInfo = New-Object System.IO.FileInfo($filePath) } catch { continue }
            if (-not $fInfo -or (-not $fInfo.Exists)) { continue }

            $fileSig = "$($fInfo.Length)|$($fInfo.LastWriteTime.ToString('yyyyMMddHHmmss'))"
            $lowPath = $filePath.ToLowerInvariant()

            # TANG 1: Fast Resume trong RAM (0.01ms)
            if ($isResume -and $resumeMap.ContainsKey($lowPath) -and ($resumeMap[$lowPath] -eq $fileSig)) {
                $script:totalSkipped++
                $script:totalScanned++
                $script:totalSafe++
            }
            # TANG 2: Zero-COM OpenXML Pre-Filter cho .xlsx/.xlsm/.xlsb (1.5 - 3ms)
            elseif (Test-OpenXmlSafeZeroCom $filePath $ext $iocRegex) {
                $script:totalZeroCom++
                $script:totalScanned++
                $script:totalSafe++
                $script:logBuffer.Add("$lowPath|$fileSig")
            }
            # TANG 3: Day vao hang doi Multi-Worker Parallel Excel COM Pool (.xls hoac tep co vbaProject.bin)
            else {
                Ensure-WorkerPoolStarted
                $comWorkQueue.Enqueue([pscustomobject]@{
                    FilePath = $filePath
                    FileName = $fileName
                    FileSig  = $fileSig
                    LowPath  = $lowPath
                })
            }

            Drain-WorkerResults
            Render-LiveDashboard $false $false

            # Dieu tiet hang doi (Backpressure): neu hang doi Deep COM > 60 tep thi cho Worker Pool xu ly bot
            while ($comWorkQueue.Count -gt 60) {
                Drain-WorkerResults
                Render-LiveDashboard $false $false
                Start-Sleep -Milliseconds 40
            }
        }

        Drain-WorkerResults
        $totalTarget = [Math]::Max([int]$sharedState.TotalTargetFiles, [int]$script:totalDiscovered)
        Flush-ScanLogs "IN_PROGRESS" $totalTarget $script:totalScanned $script:totalCleaned $startTimeStr
    }

    $sharedState.TotalTargetFiles   = $script:totalDiscovered
    $sharedState.TotalTargetFolders = $script:folderIdx
    $sharedState.CountDone          = $true

    # Cho tat ca cac tep .xls/.xlsm con lai trong hang doi Multi-Worker Pool hoan tat
    $sharedState.ProducerDone = $true
    if ($script:poolStarted) {
        while ((-not $comWorkQueue.IsEmpty) -or (-not $comResultQueue.IsEmpty)) {
            Drain-WorkerResults
            Render-LiveDashboard $false $false
            if (-not $comWorkQueue.IsEmpty) {
                Start-Sleep -Milliseconds 60
            }
        }

        foreach ($job in $script:workerJobs) {
            try { [void]$job.PowerShell.EndInvoke($job.Handle) } catch {}
        }
        Drain-WorkerResults
    }

    $stopwatch.Stop()
    $totalSec = [Math]::Round($stopwatch.Elapsed.TotalSeconds, 1)
    Render-LiveDashboard $true $true

    Flush-ScanLogs "COMPLETED" $script:totalDiscovered $script:totalScanned $script:totalCleaned $startTimeStr
    $Host.UI.RawUI.WindowTitle = "KangatangGuard v$AppVersion - HOAN TAT ($totalSec giay) | Da quet: $($script:totalScanned) | Da diet: $($script:totalCleaned)"
    Write-Host "`n   [HOAN TAT] Qua trinh quet thu muc da ket thuc trong $totalSec giay!" -ForegroundColor Green
} finally {
    try { [Console]::CursorVisible = $true } catch {}
    $sharedState.CancelWorkers = $true
    $sharedState.ProducerDone  = $true
    if ($null -ne $script:counterPs) {
        try { $script:counterPs.Dispose() } catch {}
    }
    foreach ($job in $script:workerJobs) {
        try { $job.PowerShell.Dispose() } catch {}
    }
    if ($null -ne $script:runspacePool) {
        try { $script:runspacePool.Close(); $script:runspacePool.Dispose() } catch {}
    }
}

