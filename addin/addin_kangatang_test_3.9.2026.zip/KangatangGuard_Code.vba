﻿'==============================================================================
' KangatangGuard - Excel Add-in Diet Virus Macro Kangatang
' Phien ban: v3.2.0 (Multi-Event Guard & Parent Folder Deep Clean)
' Mo ta: Tu dong quet va tieu diet virus macro Kangatang/Laroux/mypersonnel
'         ngay khi mo hoac truoc khi luu file Excel (chong OneDrive AutoSave).
'         Khi phat hien file nhiem, tu dong quet sach toan bo thu muc chua file!
'
' File nay chua toan bo ma VBA duoc phan tach theo section markers.
' PowerShell Installer se doc va inject tung phan vao dung module/class.
'==============================================================================

'### SECTION: ThisWorkbook ###
'--- Code nay se duoc inject vao ThisWorkbook cua file .xlam ---

Option Explicit

Private Sub Workbook_Open()
    ' Khoi tao Application-level event handler khi Add-in duoc load
    Call InitializeGuard
End Sub

Private Sub Workbook_BeforeClose(Cancel As Boolean)
    ' Giai phong event handler khi Add-in bi dong
    Call TerminateGuard
End Sub

'### END_SECTION: ThisWorkbook ###


'### SECTION: clsAppEvents ###
'--- Class Module: Bat su kien Application-level (WorkbookOpen, WorkbookBeforeSave, NewWorkbook) ---

Option Explicit

Public WithEvents xlApp As Excel.Application

Private Sub xlApp_WorkbookOpen(ByVal Wb As Workbook)
    On Error Resume Next
    If bIsFolderScanning Then Exit Sub
    Call ScanWorkbook(Wb)
    On Error GoTo 0
End Sub

Private Sub xlApp_WorkbookBeforeSave(ByVal Wb As Workbook, ByVal SaveAsUI As Boolean, Cancel As Boolean)
    ' Chan dung lay nhiem trong RAM truoc khi luu hoac AutoSave len OneDrive/SharePoint
    On Error Resume Next
    If bIsFolderScanning Then Exit Sub
    Call ScanWorkbook(Wb)
    On Error GoTo 0
End Sub

Private Sub xlApp_NewWorkbook(ByVal Wb As Workbook)
    ' Kiem tra file moi tao de tranh nhiem mam benh tu RAM
    On Error Resume Next
    If bIsFolderScanning Then Exit Sub
    Call ScanWorkbook(Wb)
    On Error GoTo 0
End Sub

'### END_SECTION: clsAppEvents ###


'### SECTION: modKangatangScanner ###
'--- Standard Module: Logic quet chinh, backup, lam sach va quet thu muc cha ---

Option Explicit

' --- Bien toan cuc ---
Private oAppEvents As clsAppEvents
Public bIsFolderScanning As Boolean
Private colScannedFolders As Collection

Private Const ADDIN_NAME As String = "KangatangGuard.xlam"
Private Const BACKUP_FOLDER_NAME As String = "_Backup_Kangatang"
Private Const LOG_SUBFOLDER As String = "KangatangGuard"

' --- Danh sach tu khoa virus de quet ---
Private Const VIRUS_PATTERN_NAMES As String = "Kangatang,Kangaatang,Kanga,mypersonnel"

' ===========================================================================
' Ham khoi tao va huy event handler
' ===========================================================================
Public Sub InitializeGuard()
    On Error Resume Next
    Set colScannedFolders = New Collection
    bIsFolderScanning = False
    
    Set oAppEvents = New clsAppEvents
    Set oAppEvents.xlApp = Application
    
    ' Them menu vao Add-ins tab
    Call CreateMenu
    
    WriteLog "KangatangGuard v3.2.0 da khoi dong thanh cong."
    
    ' Phong thu Race Condition: Quet ngay cac workbook da mo san
    Dim openWb As Workbook
    For Each openWb In Application.Workbooks
        Call ScanWorkbook(openWb)
    Next openWb
    
    On Error GoTo 0
End Sub

Public Sub TerminateGuard()
    On Error Resume Next
    Call RemoveMenu
    Set oAppEvents.xlApp = Nothing
    Set oAppEvents = Nothing
    Set colScannedFolders = Nothing
    bIsFolderScanning = False
    On Error GoTo 0
End Sub

' ===========================================================================
' Ham tao va xoa menu tren thanh cong cu (Add-ins tab)
' ===========================================================================
Private Sub CreateMenu()
    On Error Resume Next
    ' Xoa menu cu neu ton tai
    Call RemoveMenu
    
    Dim cmdBar As CommandBar
    Set cmdBar = Application.CommandBars("Worksheet Menu Bar")
    
    Dim menuItem As CommandBarPopup
    Set menuItem = cmdBar.Controls.Add(Type:=msoControlPopup, Temporary:=True)
    menuItem.Caption = "KangatangGuard"
    menuItem.Tag = "KangatangGuardMenu"
    
    ' Nut 1: Quet file hien tai
    Dim btn1 As CommandBarButton
    Set btn1 = menuItem.Controls.Add(Type:=msoControlButton)
    btn1.Caption = "Quet file hien tai"
    btn1.FaceId = 1088
    btn1.OnAction = "ScanActiveWorkbook"
    btn1.Tag = "KG_ScanCurrent"
    
    ' Nut 2: Quet thu muc
    Dim btn2 As CommandBarButton
    Set btn2 = menuItem.Controls.Add(Type:=msoControlButton)
    btn2.Caption = "Quet thu muc..."
    btn2.FaceId = 23
    btn2.OnAction = "ScanFolderDialog"
    btn2.Tag = "KG_ScanFolder"
    
    ' Nut 3: Mo thu muc Log
    Dim btn3 As CommandBarButton
    Set btn3 = menuItem.Controls.Add(Type:=msoControlButton)
    btn3.Caption = "Mo thu muc Log"
    btn3.FaceId = 40
    btn3.OnAction = "OpenLogFolder"
    btn3.Tag = "KG_OpenLog"
    
    ' Nut 4: Thong tin
    Dim btn4 As CommandBarButton
    Set btn4 = menuItem.Controls.Add(Type:=msoControlButton)
    btn4.Caption = "Thong tin KangatangGuard v3.2.0"
    btn4.FaceId = 487
    btn4.OnAction = "ShowAbout"
    btn4.Tag = "KG_About"
    
    On Error GoTo 0
End Sub

Private Sub RemoveMenu()
    On Error Resume Next
    Dim ctrl As CommandBarControl
    For Each ctrl In Application.CommandBars("Worksheet Menu Bar").Controls
        If ctrl.Tag = "KangatangGuardMenu" Then
            ctrl.Delete
        End If
    Next ctrl
    On Error GoTo 0
End Sub

' ===========================================================================
' Ham kiem tra whitelist (khong quet chinh minh va cac file he thong)
' ===========================================================================
Private Function IsWhitelisted(ByVal wb As Workbook) As Boolean
    IsWhitelisted = False
    On Error Resume Next
    
    ' 1. Khong quet chinh add-in nay
    If UCase(wb.Name) = UCase(ADDIN_NAME) Then
        IsWhitelisted = True
        Exit Function
    End If
    
    ' 2. Khong quet cac file .xlam (add-in khac)
    If LCase(Right(wb.Name, 5)) = ".xlam" Then
        IsWhitelisted = True
        Exit Function
    End If
    
    ' 3. Khong quet file PERSONAL.XLSB (macro ca nhan cua nguoi dung)
    If UCase(wb.Name) = "PERSONAL.XLSB" Then
        IsWhitelisted = True
        Exit Function
    End If
    
    On Error GoTo 0
End Function

' ===========================================================================
' HAM KIEM TRA MA DOC (INSPECTION ENGINE)
' ===========================================================================
Public Function CheckWorkbookInfection(ByVal wb As Workbook, ByRef detailMsg As String) As Boolean
    On Error GoTo CheckError
    CheckWorkbookInfection = False
    detailMsg = ""
    
    If IsWhitelisted(wb) Then Exit Function
    
    Dim virusKeywords() As String
    virusKeywords = Split(VIRUS_PATTERN_NAMES, ",")
    
    Dim vbProj As Object
    On Error Resume Next
    Set vbProj = wb.VBProject
    If Err.Number <> 0 Then
        WriteLog "[SKIP] " & wb.FullName & " - Khong truy cap duoc VBProject."
        Err.Clear
        On Error GoTo 0
        Exit Function
    End If
    On Error GoTo CheckError
    
    Dim comp As Object
    Dim compName As String
    Dim i As Long
    Dim kw As Long
    
    ' 1a. Quet ten Module
    For i = vbProj.VBComponents.Count To 1 Step -1
        Set comp = vbProj.VBComponents.Item(i)
        compName = comp.Name
        
        For kw = LBound(virusKeywords) To UBound(virusKeywords)
            If InStr(1, compName, Trim(virusKeywords(kw)), vbTextCompare) > 0 Then
                detailMsg = detailMsg & "  - Module doc hai: " & compName & vbCrLf
                CheckWorkbookInfection = True
                Exit For
            End If
        Next kw
    Next i
    
    ' 1b. Quet noi dung ma nguon ben trong moi component
    For i = vbProj.VBComponents.Count To 1 Step -1
        Set comp = vbProj.VBComponents.Item(i)
        On Error Resume Next
        If comp.CodeModule.CountOfLines > 0 Then
            Dim codeContent As String
            codeContent = comp.CodeModule.Lines(1, comp.CodeModule.CountOfLines)
            
            For kw = LBound(virusKeywords) To UBound(virusKeywords)
                If InStr(1, codeContent, Trim(virusKeywords(kw)), vbTextCompare) > 0 Then
                    If InStr(1, detailMsg, "Ma doc trong: " & comp.Name, vbTextCompare) = 0 Then
                        detailMsg = detailMsg & "  - Ma doc trong: " & comp.Name & vbCrLf
                        CheckWorkbookInfection = True
                    End If
                    Exit For
                End If
            Next kw
        End If
        On Error GoTo CheckError
    Next i
    
    ' 2. Quet Sheet an
    Dim sht As Object
    For i = wb.Sheets.Count To 1 Step -1
        Set sht = wb.Sheets(i)
        For kw = LBound(virusKeywords) To UBound(virusKeywords)
            If InStr(1, sht.Name, Trim(virusKeywords(kw)), vbTextCompare) > 0 Then
                detailMsg = detailMsg & "  - Sheet an doc hai: " & sht.Name & vbCrLf
                CheckWorkbookInfection = True
                Exit For
            End If
        Next kw
    Next i
    
    ' 3. Quet Hidden Named Ranges
    Dim nm As Name
    For i = wb.Names.Count To 1 Step -1
        Set nm = wb.Names(i)
        For kw = LBound(virusKeywords) To UBound(virusKeywords)
            If InStr(1, nm.Name, Trim(virusKeywords(kw)), vbTextCompare) > 0 Then
                detailMsg = detailMsg & "  - Named Range doc hai: " & nm.Name & vbCrLf
                CheckWorkbookInfection = True
                Exit For
            End If
        Next kw
        
        On Error Resume Next
        If Not nm.Visible Then
            Dim refStr As String
            refStr = nm.RefersTo
            For kw = LBound(virusKeywords) To UBound(virusKeywords)
                If InStr(1, refStr, Trim(virusKeywords(kw)), vbTextCompare) > 0 Then
                    detailMsg = detailMsg & "  - Named Range an (tham chieu doc): " & nm.Name & vbCrLf
                    CheckWorkbookInfection = True
                    Exit For
                End If
            Next kw
        End If
        On Error GoTo CheckError
    Next i
    
    Exit Function
    
CheckError:
    WriteLog "[ERROR] Loi khi kiem tra " & wb.Name & ": " & Err.Description
    On Error GoTo 0
End Function

' ===========================================================================
' HAM QUET CHINH: Quet 1 Workbook & Tu dong kich hoat quet thu muc
' ===========================================================================
Public Sub ScanWorkbook(ByVal wb As Workbook)
    On Error GoTo ScanError
    
    If IsWhitelisted(wb) Then Exit Sub
    
    Dim virusFound As Boolean
    Dim detailMsg As String
    virusFound = CheckWorkbookInfection(wb, detailMsg)
    
    If virusFound Then
        WriteLog "[DETECTED] " & wb.FullName & vbCrLf & detailMsg
        
        ' Phong thu: Kiem tra file co o che do Chi doc (Read-Only) khong
        If wb.ReadOnly Then
            WriteLog "[READONLY_DETECTED] " & wb.FullName & " la file Read-Only."
            MsgBox "CANH BAO - PHAT HIEN VIRUS KANGATANG TRONG FILE CHI DOC (READ-ONLY)!" & vbCrLf & vbCrLf & _
                   "File: " & wb.Name & vbCrLf & vbCrLf & _
                   "Chi tiet:" & vbCrLf & detailMsg & vbCrLf & _
                   "Luu y: File dang o che do Chi doc (Read-Only), he thong khong the tu dong ghi de." & vbCrLf & _
                   "Vui long mo khoa file hoac su dung 'Save As' sang ban sao moi roi chay Diet_Virus_Kangatang.bat.", _
                   vbCritical, "KangatangGuard v3.2.0"
            Exit Sub
        End If
        
        ' Backup truoc khi lam sach
        Dim backupOK As Boolean
        backupOK = BackupBeforeClean(wb)
        
        If backupOK Then
            ' Tien hanh lam sach file hien tai
            Dim cleanResult As Boolean
            cleanResult = CleanInfectedWorkbook(wb)
            
            If cleanResult Then
                WriteLog "[CLEANED] " & wb.FullName
                
                ' THONG BAO 1: Bao ket qua diet file hien tai & thong bao quet ca thu muc
                MsgBox "CANH BAO - PHAT HIEN VIRUS KANGATANG!" & vbCrLf & vbCrLf & _
                       "File: " & wb.Name & vbCrLf & vbCrLf & _
                       "Chi tiet:" & vbCrLf & detailMsg & vbCrLf & _
                       "Trang thai: DA TIEU DIET THANH CONG!" & vbCrLf & _
                       "Ban sao luu da duoc tao trong thu muc " & BACKUP_FOLDER_NAME & "\" & vbCrLf & vbCrLf & _
                       "He thong se TU DONG QUET TOAN BO THU MUC chua file nay de dam bao dap tat triet de mam benh.", _
                       vbExclamation, "KangatangGuard v3.2.0"
                
                ' KICH HOAT TU DONG QUET TOAN BO THU MUC CHA
                Dim parentDir As String
                parentDir = Left(wb.FullName, InStrRev(wb.FullName, "\"))
                If Len(parentDir) > 0 Then
                    Call ScanParentFolder(parentDir, wb.Name)
                End If
            Else
                WriteLog "[ERROR] Khong the lam sach: " & wb.FullName
                MsgBox "CANH BAO: Phat hien virus nhung KHONG THE lam sach tu dong!" & vbCrLf & _
                       "File: " & wb.Name & vbCrLf & _
                       "Vui long chay Diet_Virus_Kangatang.bat de xu ly thu cong.", _
                       vbCritical, "KangatangGuard v3.2.0"
            End If
        Else
            WriteLog "[ERROR] Khong the tao backup cho: " & wb.FullName
            MsgBox "CANH BAO: Phat hien virus nhung KHONG THE tao backup!" & vbCrLf & _
                   "File: " & wb.Name & vbCrLf & _
                   "De an toan du lieu, he thong khong tu dong sua file khi chua backup duoc. Vui long sao luu thu cong va chay Diet_Virus_Kangatang.bat.", _
                   vbCritical, "KangatangGuard v3.2.0"
        End If
    Else
        WriteLog "[SAFE] " & wb.FullName
    End If
    
    Exit Sub
    
ScanError:
    WriteLog "[ERROR] Loi khi quet " & wb.Name & ": " & Err.Description
    On Error GoTo 0
End Sub

' ===========================================================================
' HAM TU DONG QUET TOAN BO THU MUC CHA (v3.2.0 - MOI)
' ===========================================================================
Public Sub ScanParentFolder(ByVal folderPath As String, ByVal excludeFileName As String)
    On Error GoTo FolderScanError
    
    ' Phong thu Folder Cache: Tranh quet lai cung 1 thu muc trong phien
    Dim sKey As String
    sKey = UCase(folderPath)
    
    On Error Resume Next
    Dim alreadyScanned As Boolean
    alreadyScanned = False
    Dim dummy As String
    dummy = colScannedFolders(sKey)
    If Err.Number = 0 Then alreadyScanned = True
    Err.Clear
    On Error GoTo FolderScanError
    
    If alreadyScanned Then Exit Sub
    colScannedFolders.Add folderPath, sKey
    
    ' Phong thu Recursion Guard: Bat co chong le quy su kien
    bIsFolderScanning = True
    Application.EnableEvents = False
    Application.ScreenUpdating = False
    Application.DisplayAlerts = False
    
    WriteLog "[FOLDER_SCAN_START] Bat dau quet thu muc cha: " & folderPath
    
    Dim fName As String
    Dim extList As String
    extList = ".xls;.xlsm;.xlsb;.xltm;.xlt;.xla;.xlam;"
    
    Dim totalScanned As Long
    Dim totalCleaned As Long
    Dim totalSafe As Long
    totalScanned = 0
    totalCleaned = 0
    totalSafe = 0
    
    fName = Dir(folderPath & "*.*")
    Do While Len(fName) > 0
        Dim fileExt As String
        If InStrRev(fName, ".") > 0 Then
            fileExt = LCase(Mid(fName, InStrRev(fName, "."))) & ";"
        Else
            fileExt = ";"
        End If
        
        ' Bo qua file vua xu ly xong, file addin, va file khong phai Excel
        If UCase(fName) <> UCase(excludeFileName) And _
           UCase(fName) <> UCase(ADDIN_NAME) And _
           InStr(1, extList, fileExt, vbTextCompare) > 0 Then
            
            Dim fullPath As String
            fullPath = folderPath & fName
            
            Dim targetWb As Workbook
            Set targetWb = Nothing
            On Error Resume Next
            Set targetWb = Application.Workbooks.Open(FileName:=fullPath, ReadOnly:=False, UpdateLinks:=False)
            On Error GoTo FolderScanError
            
            If Not targetWb Is Nothing Then
                totalScanned = totalScanned + 1
                Dim vFound As Boolean
                Dim vDetail As String
                vFound = CheckWorkbookInfection(targetWb, vDetail)
                
                If vFound Then
                    If Not targetWb.ReadOnly Then
                        If BackupBeforeClean(targetWb) Then
                            If CleanInfectedWorkbook(targetWb) Then
                                totalCleaned = totalCleaned + 1
                                WriteLog "[FOLDER_SCAN_CLEANED] " & fullPath
                            End If
                        End If
                    Else
                        WriteLog "[FOLDER_SCAN_READONLY_SKIP] " & fullPath
                    End If
                Else
                    totalSafe = totalSafe + 1
                End If
                
                targetWb.Close SaveChanges:=False
                Set targetWb = Nothing
            End If
        End If
        
        fName = Dir()
    Loop
    
    ' Hoan nguyen trang thai an toan
    bIsFolderScanning = False
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    Application.DisplayAlerts = True
    
    WriteLog "[FOLDER_SCAN_END] " & folderPath & " - Quet: " & totalScanned & ", Diet: " & totalCleaned & ", An toan: " & totalSafe
    
    ' THONG BAO 2: Bao cao tong ket toan bo thu muc cho nguoi dung
    MsgBox "BAO CAO KET QUA QUET THU MUC:" & vbCrLf & vbCrLf & _
           "Thu muc: " & folderPath & vbCrLf & vbCrLf & _
           "  - Tong so file Excel da kiem tra : " & totalScanned & vbCrLf & _
           "  - So file phat hien & da tieu diet : " & totalCleaned & vbCrLf & _
           "  - So file an toan                  : " & totalSafe & vbCrLf & vbCrLf & _
           "Toan bo thu muc lam viec da duoc bao ve an toan!", _
           vbInformation, "KangatangGuard v3.2.0"
           
    Exit Sub
    
FolderScanError:
    bIsFolderScanning = False
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    Application.DisplayAlerts = True
    WriteLog "[FOLDER_SCAN_ERROR] Loi quet thu muc " & folderPath & ": " & Err.Description
    On Error GoTo 0
End Sub

' ===========================================================================
' HAM BACKUP: Tao ban sao file truoc khi lam sach
' ===========================================================================
Public Function BackupBeforeClean(ByVal wb As Workbook) As Boolean
    On Error GoTo BackupError
    BackupBeforeClean = False
    
    Dim filePath As String
    filePath = wb.FullName
    
    If Len(filePath) = 0 Or InStrRev(filePath, "\") = 0 Then
        Exit Function
    End If
    
    Dim parentFolder As String
    parentFolder = Left(filePath, InStrRev(filePath, "\"))
    
    Dim backupDir As String
    backupDir = parentFolder & BACKUP_FOLDER_NAME & "\"
    
    If Dir(backupDir, vbDirectory) = "" Then
        MkDir backupDir
    End If
    
    Dim timestamp As String
    timestamp = Format(Now, "yyyyMMdd_HHmmss")
    
    Dim originalName As String
    originalName = wb.Name
    
    Dim backupName As String
    backupName = Left(originalName, InStrRev(originalName, ".") - 1) & _
                 "_backup_" & timestamp & Mid(originalName, InStrRev(originalName, "."))
    
    FileCopy filePath, backupDir & backupName
    
    WriteLog "[BACKUP] Da tao ban sao: " & backupDir & backupName
    BackupBeforeClean = True
    Exit Function
    
BackupError:
    WriteLog "[BACKUP_ERROR] " & Err.Description
    BackupBeforeClean = False
End Function

' ===========================================================================
' HAM LAM SACH: Xoa toan bo thanh phan nhiem virus
' ===========================================================================
Public Function CleanInfectedWorkbook(ByVal wb As Workbook) As Boolean
    On Error GoTo CleanError
    CleanInfectedWorkbook = False
    
    Dim virusKeywords() As String
    virusKeywords = Split(VIRUS_PATTERN_NAMES, ",")
    
    Dim vbProj As Object
    Set vbProj = wb.VBProject
    
    Dim i As Long
    Dim kw As Long
    Dim comp As Object
    Dim cleaned As Boolean
    cleaned = False
    
    ' 1. Xoa cac VBA Module doc hai (chi xoa Module 1 va Class 2, khong xoa Document 100)
    For i = vbProj.VBComponents.Count To 1 Step -1
        Set comp = vbProj.VBComponents.Item(i)
        
        If comp.Type = 1 Or comp.Type = 2 Then
            For kw = LBound(virusKeywords) To UBound(virusKeywords)
                If InStr(1, comp.Name, Trim(virusKeywords(kw)), vbTextCompare) > 0 Then
                    vbProj.VBComponents.Remove comp
                    cleaned = True
                    Exit For
                End If
            Next kw
        End If
    Next i
    
    ' 2. Xoa noi dung ma doc ben trong cac Document modules (ThisWorkbook, Sheet1, v.v.)
    For i = vbProj.VBComponents.Count To 1 Step -1
        Set comp = vbProj.VBComponents.Item(i)
        On Error Resume Next
        If comp.CodeModule.CountOfLines > 0 Then
            Dim codeText As String
            codeText = comp.CodeModule.Lines(1, comp.CodeModule.CountOfLines)
            
            For kw = LBound(virusKeywords) To UBound(virusKeywords)
                If InStr(1, codeText, Trim(virusKeywords(kw)), vbTextCompare) > 0 Then
                    comp.CodeModule.DeleteLines 1, comp.CodeModule.CountOfLines
                    cleaned = True
                    Exit For
                End If
            Next kw
        End If
        On Error GoTo CleanError
    Next i
    
    ' 3. Xoa Sheet an doc hai
    Application.DisplayAlerts = False
    For i = wb.Sheets.Count To 1 Step -1
        If wb.Sheets.Count > 1 Then
            Dim shtName As String
            shtName = wb.Sheets(i).Name
            
            For kw = LBound(virusKeywords) To UBound(virusKeywords)
                If InStr(1, shtName, Trim(virusKeywords(kw)), vbTextCompare) > 0 Then
                    wb.Sheets(i).Visible = xlSheetVisible
                    wb.Sheets(i).Delete
                    cleaned = True
                    Exit For
                End If
            Next kw
        End If
    Next i
    Application.DisplayAlerts = True
    
    ' 4. Xoa Hidden Named Ranges doc hai
    Dim nm As Name
    For i = wb.Names.Count To 1 Step -1
        Set nm = wb.Names(i)
        Dim shouldDelete As Boolean
        shouldDelete = False
        
        For kw = LBound(virusKeywords) To UBound(virusKeywords)
            If InStr(1, nm.Name, Trim(virusKeywords(kw)), vbTextCompare) > 0 Then
                shouldDelete = True
                Exit For
            End If
        Next kw
        
        If Not shouldDelete Then
            On Error Resume Next
            If Not nm.Visible Then
                Dim refText As String
                refText = nm.RefersTo
                For kw = LBound(virusKeywords) To UBound(virusKeywords)
                    If InStr(1, refText, Trim(virusKeywords(kw)), vbTextCompare) > 0 Then
                        shouldDelete = True
                        Exit For
                    End If
                Next kw
            End If
            On Error GoTo CleanError
        End If
        
        If shouldDelete Then
            On Error Resume Next
            nm.Delete
            cleaned = True
            On Error GoTo CleanError
        End If
    Next i
    
    ' Luu file sau khi lam sach
    If cleaned Then
        wb.Save
    End If
    
    CleanInfectedWorkbook = True
    Exit Function
    
CleanError:
    Application.DisplayAlerts = True
    CleanInfectedWorkbook = False
End Function

' ===========================================================================
' HAM MENU: Quet file hien tai (goi tu menu)
' ===========================================================================
Public Sub ScanActiveWorkbook()
    If ActiveWorkbook Is Nothing Then
        MsgBox "Khong co file Excel nao dang mo.", vbInformation, "KangatangGuard"
        Exit Sub
    End If
    
    Dim wbName As String
    wbName = ActiveWorkbook.Name
    
    Call ScanWorkbook(ActiveWorkbook)
    
    MsgBox "Da hoan thanh quet file: " & wbName & vbCrLf & _
           "Xem chi tiet tai thu muc Log.", _
           vbInformation, "KangatangGuard v3.2.0"
End Sub

' ===========================================================================
' HAM MENU: Quet thu muc (goi tu menu, hien hop thoai chon thu muc)
' ===========================================================================
Public Sub ScanFolderDialog()
    Dim fd As FileDialog
    Set fd = Application.FileDialog(msoFileDialogFolderPicker)
    fd.Title = "KangatangGuard - Chon thu muc can quet"
    fd.ButtonName = "Quet thu muc nay"
    
    If fd.Show = -1 Then
        Dim folderPath As String
        folderPath = fd.SelectedItems(1)
        If Right(folderPath, 1) <> "\" Then folderPath = folderPath & "\"
        
        Call ScanParentFolder(folderPath, "")
    End If
End Sub

' ===========================================================================
' HAM MENU: Mo thu muc Log
' ===========================================================================
Public Sub OpenLogFolder()
    Dim logDir As String
    logDir = Environ("APPDATA") & "\" & LOG_SUBFOLDER
    
    If Dir(logDir, vbDirectory) = "" Then
        MkDir logDir
    End If
    
    Shell "explorer.exe """ & logDir & """", vbNormalFocus
End Sub

' ===========================================================================
' HAM MENU: Hien thi thong tin Add-in
' ===========================================================================
Public Sub ShowAbout()
    MsgBox "KangatangGuard v3.2.0" & vbCrLf & vbCrLf & _
           "Add-in bao ve Excel chong virus macro Kangatang/Laroux" & vbCrLf & _
           "Tu dong quet khi mo file, truoc khi luu (chong OneDrive AutoSave)" & vbCrLf & _
           "va tu dong quet sach ca thu muc khi phat hien mam benh!" & vbCrLf & vbCrLf & _
           "Phien ban kien truc: v3.2.0 Production-grade", _
           vbInformation, "KangatangGuard"
End Sub

'### END_SECTION: modKangatangScanner ###


'### SECTION: modLogger ###
'--- Standard Module: Ghi log kiem toan ra file ---

Option Explicit

Private Const LOG_FOLDER As String = "KangatangGuard"

Public Sub WriteLog(ByVal msg As String)
    On Error Resume Next
    
    Dim logDir As String
    logDir = Environ("APPDATA") & "\" & LOG_FOLDER
    
    If Dir(logDir, vbDirectory) = "" Then
        MkDir logDir
    End If
    
    Dim logFile As String
    logFile = logDir & "\scan_log_" & Format(Now, "yyyyMMdd") & ".txt"
    
    Dim fNum As Integer
    fNum = FreeFile
    Open logFile For Append As #fNum
    Print #fNum, Format(Now, "yyyy-MM-dd HH:mm:ss") & " | " & msg
    Close #fNum
    
    On Error GoTo 0
End Sub

'### END_SECTION: modLogger ###
